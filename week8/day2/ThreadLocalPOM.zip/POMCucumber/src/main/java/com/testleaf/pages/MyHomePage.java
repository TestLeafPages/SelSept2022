package com.testleaf.pages;

import org.openqa.selenium.chrome.ChromeDriver;

import com.testleaf.base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods{

//	public MyHomePage(ChromeDriver driver) {
//		this.driver = driver;
//	}
	
	public LeadsPage clickLeads() {
		
		return new LeadsPage();
	}
}
