package com.testleaf.pages;

import org.openqa.selenium.chrome.ChromeDriver;

import com.testleaf.base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods{

//	public ViewLeadPage(ChromeDriver driver) {
//		this.driver = driver;
//	}
}
